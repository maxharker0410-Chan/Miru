"""Standalone S.Chat &《魔法異世界》V1.5.0 Flask Server."""
from __future__ import annotations

from datetime import datetime
from io import BytesIO
import json
import os
from pathlib import Path
import sys
import time
import uuid

from flask import Flask, Response, g, jsonify, redirect, render_template, request, send_from_directory
from flask_compress import Compress
from PIL import Image, UnidentifiedImageError

import ai_config
import auth
import owner_config
import story_engine

app = Flask(__name__)
Compress(app)

_is_client_mode = False
_client_mode_config = None
_BUILD_VERSION = None


def _get_version() -> str:
    global _BUILD_VERSION
    if _BUILD_VERSION is None:
        _BUILD_VERSION = datetime.now().strftime("%Y%m%d%H%M%S")
    return _BUILD_VERSION


def _bundled_resource_root() -> str:
    return getattr(sys, "_MEIPASS", os.path.dirname(__file__))


def _story_user_dir():
    return getattr(g, "user_data_dir", None)


@app.before_request
def _before_request():
    return auth.check_request(request)


@app.after_request
def _after_request(response):
    origin = request.headers.get("Origin", "")
    allowed_prefixes = [
        "http://localhost",
        "http://127.0.0.1",
        "https://localhost",
        "http://192.168.",
        "http://10.",
        "http://172.",
    ]
    domain = os.environ.get("DOMAIN", "").strip().rstrip("/")
    tunnel_url = os.environ.get("TUNNEL_URL", "").strip().rstrip("/")
    if domain:
        allowed_prefixes.append(f"https://{domain}")
    if tunnel_url:
        allowed_prefixes.append(tunnel_url)
    if any(origin == p or origin.startswith(p) for p in allowed_prefixes):
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, If-None-Match"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        response.headers["Access-Control-Expose-Headers"] = "ETag"
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        if request.path.startswith("/api/schat/assets/") and response.status_code == 200:
            response.headers["Cache-Control"] = "private, max-age=86400"
            response.headers.pop("Pragma", None)
            response.headers.pop("Expires", None)
    return response


@app.errorhandler(story_engine.StoryError)
def _story_error(error):
    from world_runtime import ConflictError
    return jsonify({"error": str(error)}), 409 if isinstance(error, ConflictError) else 400


# ===== Public & Shell Routes =====

@app.route("/api/health")
def api_health():
    return {"ok": True, "ts": time.time()}


@app.route("/")
@app.route("/app")
def root_redirect():
    query = request.query_string.decode("utf-8", errors="ignore")
    target = f"/s-chat?{query}" if query else "/s-chat"
    return redirect(target, code=302)


@app.route("/s-chat")
def s_chat_page():
    resp = app.make_response(render_template("s-chat.html"))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/s-chat/manifest.json")
def schat_manifest():
    return send_from_directory(
        _bundled_resource_root(),
        "schat-manifest.json",
        mimetype="application/manifest+json",
    )


@app.route("/s-chat/service-worker.js")
def schat_service_worker():
    resp = send_from_directory(
        _bundled_resource_root(),
        "schat-service-worker.js",
        mimetype="application/javascript",
    )
    resp.headers["Service-Worker-Allowed"] = "/s-chat"
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.route("/login")
def login_page():
    resp = app.make_response(render_template("login.html"))
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp


@app.route("/privacy")
def privacy_page():
    resp = app.make_response(render_template("privacy.html"))
    resp.headers["Cache-Control"] = "public, max-age=3600"
    return resp


@app.route("/assets/brand/<path:filename>")
def serve_brand_asset(filename):
    return send_from_directory(
        os.path.join(_bundled_resource_root(), "assets", "brand"),
        filename,
    )


@app.route("/assets/js/schat.js")
@app.route("/assets/js/schat-library.js")
def serve_schat_js():
    return send_from_directory(
        os.path.join(_bundled_resource_root(), "assets", "js"),
        request.path.rsplit("/", 1)[-1],
        mimetype="application/javascript",
    )


@app.route("/favicon.ico")
def serve_favicon():
    return send_from_directory(
        os.path.join(_bundled_resource_root(), "assets", "brand"),
        "schat.ico",
    )


# ===== Auth & Account Routes =====

@app.route("/api/auth/login", methods=["POST"])
def api_auth_login():
    body = request.get_json(silent=True) or {}
    code = (body.get("code") or "").strip()
    if not code:
        return jsonify({"error": "請輸入邀請碼"}), 400
    result = auth.login_with_code(code)
    if not result:
        return jsonify({"error": "邀請碼無效或已被停用"}), 401
    return jsonify(result)


@app.route("/api/auth/me", methods=["GET"])
def api_auth_me():
    return jsonify({
        "user_id": getattr(g, "user_id", "_admin"),
        "is_admin": getattr(g, "is_admin", False),
    })


@app.route("/api/auth/invitation", methods=["GET"])
def api_auth_invitation():
    user_id = getattr(g, "user_id", None)
    if not user_id or user_id == "_admin" or getattr(g, "is_admin", False):
        return jsonify({"ok": False, "error": "需要先登入"}), 401
    info = auth.get_user_invitation_info(user_id)
    if not info:
        return jsonify({"ok": False, "error": "當前帳號尚未保存完整邀請碼"}), 404
    return jsonify({"ok": True, **info})


@app.route("/api/auth/logout", methods=["POST"])
def api_auth_logout():
    global _client_mode_config
    _client_mode_config = None
    return jsonify({"ok": True})


@app.route("/api/auth/export", methods=["GET"])
def api_auth_export():
    user_id = getattr(g, "user_id", None)
    if not user_id or getattr(g, "is_admin", False):
        return jsonify({"error": "login required"}), 401
    bundle = auth.export_user_data(user_id)
    if bundle is None:
        return jsonify({"error": "user data not found"}), 404
    body = json.dumps(bundle, ensure_ascii=False, indent=2)
    resp = Response(body, content_type="application/json")
    resp.headers["Content-Disposition"] = f'attachment; filename="schat-export-{user_id}.json"'
    return resp


@app.route("/api/auth/account", methods=["DELETE"])
def api_auth_delete_account():
    user_id = getattr(g, "user_id", None)
    if not user_id or getattr(g, "is_admin", False):
        return jsonify({"error": "login required"}), 401
    body = request.get_json(silent=True) or {}
    if (body.get("confirm") or "").strip() != "DELETE":
        return jsonify({"error": "confirmation required"}), 400
    reason = (body.get("reason") or "user_self_delete")[:200]
    result = auth.delete_user(user_id, reason=reason)
    if not result.get("ok"):
        return jsonify(result), 500
    return jsonify({
        "ok": True,
        "bytes_freed": result.get("bytes_freed", 0),
        "invitation_code": result.get("invitation_code"),
    })


@app.route("/api/client-config")
def api_client_config():
    if _client_mode_config:
        return jsonify({
            "client_mode": True,
            "server_url": _client_mode_config.get("server_url", ""),
            "auth_token": _client_mode_config.get("auth_token", ""),
            "mode": _client_mode_config.get("mode", ""),
            "local_only": bool(_client_mode_config.get("local_only")),
            "setup_complete": bool(_client_mode_config.get("setup_complete")),
        })
    return jsonify({"client_mode": False})


@app.route("/api/client/local/start", methods=["POST"])
def api_client_local_start():
    global _client_mode_config, _is_client_mode
    if not auth.is_local_request(request):
        return jsonify({"error": "local client only"}), 403
    result = auth.get_or_create_local_single_device_user()
    host = request.host or "127.0.0.1:5001"
    port = host.rsplit(":", 1)[-1] if ":" in host else "5001"
    server_url = f"http://127.0.0.1:{port}"
    _is_client_mode = True
    _client_mode_config = {
        "server_url": server_url,
        "auth_token": result["token"],
        "user_id": result["user_id"],
        "mode": "local",
        "local_only": True,
        "setup_complete": not bool(result.get("is_new")),
    }
    return jsonify({
        "ok": True,
        **result,
        "server_url": server_url,
        "invitation_code": "",
    })


# ===== S.Chat & Magic World V1.5.0 Routes =====

@app.route("/api/schat/account")
def api_schat_account():
    return jsonify({"user_id": g.user_id})


@app.route("/api/schat/world-import", methods=["POST"])
def api_schat_world_import():
    from world_import import import_packages, MAX_UPLOAD
    request.max_content_length = MAX_UPLOAD
    if (request.content_length or 0) > MAX_UPLOAD:
        return jsonify({"error": "兩份 ZIP 合計請小於 512 MB。"}), 413
    world = request.files.get("world_zip")
    images = request.files.get("images_zip")
    if not world or not images:
        return jsonify({"error": "請一次選擇世界資料包及 WebP 圖片包。"}), 400
    try:
        result = import_packages(_story_user_dir(), world.stream, images.stream)
    except story_engine.StoryError:
        raise
    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "資料包索引格式不完整，既有故事與紀錄未變更。"}), 400
    return jsonify(result), 200 if result["already_imported"] else 201


@app.route("/api/schat/stories/<story_id>/sessions/<session_id>/world-action", methods=["POST"])
def api_schat_world_action(story_id, session_id):
    import world_runtime
    return jsonify(world_runtime.action(_story_user_dir(), story_id, session_id, request.get_json(silent=True)))


@app.route("/api/schat/stories/<story_id>/world-settings", methods=["POST"])
def api_schat_world_settings(story_id):
    from world_settings import apply_document, MAX_DOCUMENT
    request.max_content_length = MAX_DOCUMENT
    if (request.content_length or 0) > MAX_DOCUMENT:
        return jsonify({"error": "Word 設定書請小於 16 MB。"}), 413
    document = request.files.get("world_document")
    if not document or not (document.filename or "").lower().endswith(".docx"):
        return jsonify({"error": "請選擇完整的魔法異世界 Word 設定書（.docx）。"}), 400
    revision = request.form.get("base_settings_revision", "")
    if not revision.isdecimal():
        return jsonify({"error": "請重新載入故事後更新設定書。"}), 400
    return jsonify(apply_document(_story_user_dir(), story_id, document.stream, int(revision)))


@app.route("/api/schat/model", methods=["GET", "PUT"])
def api_schat_model():
    if request.method == "GET":
        return jsonify(story_engine.model_status(_story_user_dir()))
    return jsonify(story_engine.save_model(_story_user_dir(), request.get_json(silent=True)))


@app.route("/api/schat/stories/<story_id>/content-release", methods=["POST"])
def api_schat_content_release(story_id):
    import world_release
    request.max_content_length = world_release.MAX_RELEASE
    package = request.files.get("content_zip")
    if not package:
        return jsonify({"error": "請選擇完整測試資料 ZIP。"}), 400
    return jsonify(world_release.install(
        _story_user_dir(),
        story_id,
        package.stream,
        request.form.get("base_content_version", ""),
    ))


@app.route("/api/schat/stories/<story_id>/content-release/bundled", methods=["POST"])
def api_schat_content_release_bundled(story_id):
    import world_release
    body = request.get_json(silent=True) or {}
    return jsonify(world_release.install_bundled(
        _story_user_dir(),
        story_id,
        body.get("base_content_version"),
    ))


@app.route("/api/schat/model/test", methods=["POST"])
def api_schat_model_test():
    try:
        answer = story_engine._model(_story_user_dir(), '只輸出 JSON：{"ok":true}', "測試連線", "schat_test")
        if not isinstance(answer, dict):
            raise ValueError("回覆格式錯誤")
        return jsonify({"ok": True})
    except Exception as error:
        app.logger.warning("S. Chat model test failed: %s", error)
        return jsonify({"error": "模型連線失敗，請檢查服務地址、模型 ID 和 API Key。"}), 502


@app.route("/api/schat/stories", methods=["GET", "POST"])
def api_schat_stories():
    if request.method == "GET":
        return jsonify({"stories": story_engine.list_stories(_story_user_dir())})
    return jsonify(story_engine.save_story(_story_user_dir(), request.get_json(silent=True))), 201


@app.route("/api/schat/stories/<story_id>", methods=["GET", "PUT", "DELETE"])
def api_schat_story(story_id):
    if request.method == "GET":
        return jsonify(story_engine.get_story(_story_user_dir(), story_id))
    if request.method == "DELETE":
        story_engine.delete_story(_story_user_dir(), story_id)
        return jsonify({"ok": True})
    return jsonify(story_engine.save_story(_story_user_dir(), request.get_json(silent=True), story_id))


@app.route("/api/schat/stories/<story_id>/sessions", methods=["GET", "POST"])
def api_schat_start(story_id):
    if request.method == "GET":
        return jsonify({"sessions": story_engine.list_sessions(_story_user_dir(), story_id)})
    body = request.get_json(silent=True)
    test_run = isinstance(body, dict) and body.get("test_run") is True
    return jsonify(story_engine.start_session(_story_user_dir(), story_id, test_run=test_run)), 201


@app.route("/api/schat/stories/<story_id>/sessions/<session_id>")
def api_schat_session(story_id, session_id):
    return jsonify(story_engine.get_session(_story_user_dir(), story_id, session_id))


@app.route("/api/schat/stories/<story_id>/sessions/<session_id>/advance", methods=["POST"])
def api_schat_advance(story_id, session_id):
    body = request.get_json(silent=True) or {}
    return jsonify(story_engine.advance(
        _story_user_dir(),
        story_id,
        session_id,
        body.get("scene_id"),
        body.get("event_id"),
        body.get("base_revision"),
    ))


@app.route("/api/schat/stories/<story_id>/sessions/<session_id>/visuals", methods=["PATCH"])
def api_schat_visuals(story_id, session_id):
    body = request.get_json(silent=True) or {}
    return jsonify(story_engine.set_visual(
        _story_user_dir(),
        story_id,
        session_id,
        body.get("character_id"),
        body.get("state_id"),
        body.get("locked"),
    ))


@app.route("/api/schat/stories/<story_id>/sessions/<session_id>/turn", methods=["POST"])
def api_schat_turn(story_id, session_id):
    body = request.get_json(silent=True) or {}
    try:
        return jsonify(story_engine.take_turn(
            _story_user_dir(),
            story_id,
            session_id,
            body.get("text"),
            event_id=body.get("event_id"),
            base_revision=body.get("base_revision"),
        ))
    except story_engine.StoryError:
        raise
    except Exception as error:
        app.logger.warning("S. Chat model error: %s", error)
        return jsonify({"error": "角色暫時無法回應，請檢查聊天模型設定後重試。"}), 502


@app.route("/api/schat/assets", methods=["POST"])
def api_schat_upload():
    uploaded = request.files.get("image")
    if not uploaded or (request.content_length or 0) > 9 * 1024 * 1024:
        return jsonify({"error": "請上傳小於 8 MB 的 PNG、JPG 或 WebP 圖片"}), 400
    raw = uploaded.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return jsonify({"error": "圖片超過 8 MB"}), 400
    try:
        with Image.open(BytesIO(raw)) as image:
            image.verify()
        with Image.open(BytesIO(raw)) as image:
            if image.width > 6000 or image.height > 6000:
                raise ValueError("圖片尺寸超過限制")
            ext = {"PNG": "png", "JPEG": "jpg", "WEBP": "webp"}.get(image.format)
    except (UnidentifiedImageError, OSError, ValueError):
        ext = None
    if not ext:
        return jsonify({"error": "圖片格式或尺寸不支援"}), 400
    root = story_engine._root(_story_user_dir()) / "media"
    root.mkdir(parents=True, exist_ok=True)
    name = uuid.uuid4().hex + "." + ext
    (root / name).write_bytes(raw)
    return jsonify({"file": name, "url": "/api/schat/assets/" + name}), 201


@app.route("/api/schat/assets/<name>")
def api_schat_asset(name):
    if not story_engine._IMAGE.fullmatch(name):
        return jsonify({"error": "無效圖片"}), 404
    return send_from_directory(story_engine._root(_story_user_dir()) / "media", name)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5001"))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(debug=debug, host="0.0.0.0", port=port)
