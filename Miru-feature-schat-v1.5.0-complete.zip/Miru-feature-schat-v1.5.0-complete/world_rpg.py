"""Executable RPG mechanics for S.Chat Magic World V1.5.0.

Implements:
- 54 important characters + player stats, levels (Lv.1-30), and signature_skills
- 8 base jobs, 16 specialist branches, 9 advanced classes, 4 independent modules
- Physical & magical damage formulas, pressure (滿3開啟破綻), Phase 2 (<=50% HP x1.2)
- Compound element split calculation (複合元素分段判定, floored per segment)
- Quiver ammunition tracking & post-encounter arrow recovery (70% / 30% / 0%)
- Equipment instances (6 slots, 2-handed weapon rules, I08/I12 single-instance protection)
- Finite shops, periodic 16-tick market restock, chests, forge crafting, 65% steal once
- Safe hub rest (10 gold or rescue debt repaid from future rewards)
- 47 executable quests (visit, talk, investigate, encounter, choose)
- 52 enemies (including WB01 & WB02) with precast signals and non-combat resolutions
"""
from __future__ import annotations

import copy
import hashlib
import uuid
import story_engine as engine

BASE_JOBS = {
    'warrior': {'name': '劍士', 'element': 'slash', 'power': 150, 'sp_cost': 12, 'mp_cost': 0, 'kind': 'physical'},
    'dancer': {'name': '舞孃', 'element': 'blunt', 'power': 150, 'sp_cost': 10, 'mp_cost': 0, 'kind': 'physical'},
    'merchant': {'name': '商人', 'element': 'blunt', 'power': 150, 'sp_cost': 10, 'mp_cost': 0, 'kind': 'physical'},
    'scholar': {'name': '學者', 'element': 'magic', 'power': 150, 'sp_cost': 0, 'mp_cost': 12, 'kind': 'magic'},
    'thief': {'name': '盜賊', 'element': 'pierce', 'power': 150, 'sp_cost': 10, 'mp_cost': 0, 'kind': 'physical'},
    'cleric': {'name': '神官', 'element': 'heal', 'power': 150, 'sp_cost': 0, 'mp_cost': 12, 'kind': 'heal'},
    'hunter': {'name': '獵人', 'element': 'pierce', 'power': 150, 'sp_cost': 12, 'mp_cost': 0, 'kind': 'physical'},
    'apothecary': {'name': '藥師', 'element': 'heal', 'power': 150, 'sp_cost': 10, 'mp_cost': 0, 'kind': 'heal'},
}

PHYSICAL_ELEMENTS = {'slash', 'pierce', 'blunt'}
MAGIC_ELEMENTS = {'magic', 'fire', 'ice', 'water', 'wind', 'lightning', 'light', 'dark'}
SLOTS = ('main', 'off', 'body', 'accessory1', 'accessory2', 'tool')
HARD_ENV_REGIONS = {'region_06', 'region_09'}


def _rpg_def(story):
    return (story.get('world', {}).get('content_release', {}) or {}).get('rpg') or {}


def initialize(story, session):
    """Initialize or reconcile per-session RPG state without overwriting progress."""
    state = session.get('world_state')
    if not isinstance(state, dict):
        return False
    rpg_def = _rpg_def(story)
    if not rpg_def:
        return False
    changed = False
    rpg = state.get('rpg')
    if not isinstance(rpg, dict):
        initial = rpg_def.get('initial', {})
        rpg = {
            'version': rpg_def.get('version', 2),
            'gold': int(initial.get('gold', 100)),
            'rescue_debt': 0,
            'quiver': {'arrows': 12, 'max_arrows': 12, 'spent_this_encounter': 0},
            'actors': {},
            'inventory': [],
            'sources': {},
            'quests': {},
            'encounters': {
                'active': None,
                'defeated_ids': [],
                'resolved_ids': [],
                'looted_ids': [],
                'obsidian_sword_transferred': False,
            },
        }
        for entry in initial.get('items', []):
            count = int(entry.get('count', 1))
            for _ in range(count):
                rpg['inventory'].append({
                    'instance_id': 'inst_' + uuid.uuid4().hex[:12],
                    'item_id': entry['item_id'],
                    'owner': 'player',
                    'equipped_by': None,
                    'slot': None,
                    'used': False,
                    'source_id': 'initial',
                })
        state['rpg'] = rpg
        changed = True

    if 'quiver' not in rpg or not isinstance(rpg['quiver'], dict):
        rpg['quiver'] = {'arrows': 12, 'max_arrows': 12, 'spent_this_encounter': 0}
        changed = True
    if 'rescue_debt' not in rpg:
        rpg['rescue_debt'] = 0
        changed = True

    actors_def = rpg_def.get('actors', {})
    for aid, adef in actors_def.items():
        if aid not in rpg['actors']:
            st = adef.get('stats', {})
            hp = int(st.get('hp', 100))
            mp = int(st.get('mp', 0))
            sp = int(st.get('sp', 100))
            rpg['actors'][aid] = {
                'id': aid,
                'name': adef.get('name', aid),
                'job': adef.get('job', 'warrior'),
                'level': 1,
                'xp': 0,
                'hp': hp,
                'max_hp': hp,
                'mp': mp,
                'max_mp': mp,
                'sp': sp,
                'max_sp': sp,
                'attack': int(st.get('attack', 20)),
                'defense': int(st.get('defense', 10)),
                'magic': int(st.get('magic', 10)),
                'resist': int(st.get('resist', 10)),
                'speed': int(st.get('speed', 12)),
                'skill_elements': list(adef.get('skill_elements', [])),
                'specialist_branch': adef.get('specialist_branch'),
                'advanced_class': adef.get('advanced_class'),
                'advanced_unlocked': aid != 'player',
                'independent_module': adef.get('independent_module'),
                'statuses': [],
                'overload_streak': 0,
                'equipment': {slot: None for slot in SLOTS},
            }
            changed = True
        else:
            actor = rpg['actors'][aid]
            st = adef.get('stats', {})
            # Sync newly calibrated MP or V1.5.0 branch metadata on existing saves
            if int(st.get('mp', 0)) > actor.get('max_mp', 0) and actor.get('level', 1) == 1:
                diff = int(st['mp']) - actor['max_mp']
                actor['max_mp'] = int(st['mp'])
                actor['mp'] = min(actor['max_mp'], actor.get('mp', 0) + diff)
                changed = True
            for field in ('specialist_branch', 'advanced_class', 'independent_module', 'skill_elements'):
                if field in adef and not actor.get(field):
                    actor[field] = copy.deepcopy(adef[field])
                    changed = True

    sources_def = rpg_def.get('sources', {})
    for sid, sdef in sources_def.items():
        if sid not in rpg['sources']:
            stock = []
            for row in sdef.get('stock', []):
                stock.append({
                    'item_id': row['item_id'],
                    'count': int(row.get('count', 1)),
                    'max_count': int(row.get('count', 1)),
                    'price': int(row.get('price', 0)),
                    'material': row.get('material'),
                })
            rpg['sources'][sid] = {
                'id': sid,
                'name': sdef.get('name', sid),
                'kind': sdef.get('kind', 'shop'),
                'region_id': sdef.get('region_id'),
                'scene_id': sdef.get('scene_id'),
                'requires': sdef.get('requires'),
                'locked': bool(sdef.get('locked', False)),
                'key_item': sdef.get('key_item'),
                'stealable': bool(sdef.get('stealable', False)),
                'stolen_attempted': False,
                'alerted': False,
                'restock_interval_ticks': sdef.get('restock_interval_ticks'),
                'last_restock_tick': 0,
                'stock': stock,
            }
            changed = True
        else:
            existing_src = rpg['sources'][sid]
            existing_items = {r['item_id'] for r in existing_src.get('stock', [])}
            for row in sdef.get('stock', []):
                if row['item_id'] not in existing_items:
                    existing_src.setdefault('stock', []).append({
                        'item_id': row['item_id'],
                        'count': int(row.get('count', 1)),
                        'max_count': int(row.get('count', 1)),
                        'price': int(row.get('price', 0)),
                        'material': row.get('material'),
                    })
                    changed = True
            if sdef.get('restock_interval_ticks') and not existing_src.get('restock_interval_ticks'):
                existing_src['restock_interval_ticks'] = sdef['restock_interval_ticks']
                changed = True

    quests_def = rpg_def.get('quests', {})
    for qid in quests_def:
        if qid not in rpg['quests']:
            rpg['quests'][qid] = {
                'id': qid,
                'status': 'seed',
                'step_index': 0,
                'completed_steps': [],
                'choice': None,
                'consequence': None,
                'reward_claimed': False,
            }
            changed = True

    return changed


def effective_stats(story, session, actor_id):
    """Calculate effective stats including equipped item bonuses and I08 loss penalty."""
    rpg_def = _rpg_def(story)
    items_def = rpg_def.get('items', {})
    rpg = session['world_state']['rpg']
    actor = rpg['actors'][actor_id]
    result = {k: int(actor[k]) for k in ('hp', 'max_hp', 'mp', 'max_mp', 'sp', 'max_sp',
                                         'attack', 'defense', 'magic', 'resist', 'speed')}
    by_id = {inst['instance_id']: inst for inst in rpg['inventory']}
    main_element = 'blunt'
    for slot, inst_id in (actor.get('equipment') or {}).items():
        if not inst_id or inst_id not in by_id:
            continue
        inst = by_id[inst_id]
        if inst.get('used'):
            continue
        idef = items_def.get(inst['item_id'], {})
        for stat_key, bonus in (idef.get('bonuses') or {}).items():
            if stat_key in result:
                result[stat_key] += int(bonus)
        if slot == 'main' and idef.get('element'):
            main_element = idef['element']
    if actor_id == 'char_07_lord' and rpg['encounters'].get('obsidian_sword_transferred'):
        has_i08 = any(
            by_id.get(iid, {}).get('item_id') == 'I08'
            for iid in (actor.get('equipment') or {}).values() if iid
        )
        if not has_i08:
            result['attack'] = max(1, result['attack'] - 10)
    result['main_element'] = main_element
    return result


def _award_gold(rpg, amount):
    amount = int(amount)
    if amount <= 0:
        return 0, 0
    debt = int(rpg.get('rescue_debt', 0))
    repaid = min(debt, amount)
    rpg['rescue_debt'] = debt - repaid
    net = amount - repaid
    rpg['gold'] = int(rpg.get('gold', 0)) + net
    return net, repaid


def _award_xp(rpg, actor_ids, amount):
    amount = int(amount)
    if amount <= 0:
        return []
    leveled = []
    for aid in actor_ids:
        actor = rpg['actors'].get(aid)
        if not actor:
            continue
        actor['xp'] = int(actor.get('xp', 0)) + amount
        while actor['level'] < 30 and actor['xp'] >= actor['level'] * 100:
            actor['level'] += 1
            actor['max_hp'] += 10
            actor['attack'] += 2
            actor['defense'] += 2
            actor['magic'] += 2
            actor['resist'] += 2
            if actor['level'] >= 3:
                actor['advanced_unlocked'] = True
            leveled.append((actor['name'], actor['level']))
    return leveled


def _give_item(rpg, item_id, source_id, count=1):
    created = []
    for _ in range(int(count)):
        inst = {
            'instance_id': 'inst_' + uuid.uuid4().hex[:12],
            'item_id': item_id,
            'owner': 'player',
            'equipped_by': None,
            'slot': None,
            'used': False,
            'source_id': source_id,
        }
        rpg['inventory'].append(inst)
        created.append(inst)
    return created


def check_market_restock(story, session):
    """Replenish regional consumable supply shops every 16 world_ticks."""
    state = session.get('world_state') or {}
    rpg = state.get('rpg')
    if not isinstance(rpg, dict):
        return []
    tick = int(state.get('world_tick', 0))
    items_def = _rpg_def(story).get('items', {})
    restocked = []
    for sid, src in rpg.get('sources', {}).items():
        interval = int(src.get('restock_interval_ticks') or 0)
        if interval <= 0 or src.get('kind') != 'shop' or src.get('alerted'):
            continue
        if tick - int(src.get('last_restock_tick', 0)) >= interval:
            src['last_restock_tick'] = tick
            changed = False
            for row in src.get('stock', []):
                idef = items_def.get(row['item_id'], {})
                if idef.get('unique') or idef.get('kind') != 'consumable':
                    continue
                max_c = int(row.get('max_count', 3))
                if int(row.get('count', 0)) < max_c:
                    row['count'] = max_c
                    changed = True
            if changed:
                restocked.append(sid)
    return restocked


def sync_quest_progress(story, session, trigger_kind, target_id):
    """Automatically advance active (or eligible seed) quest visit/talk/encounter steps."""
    rpg_def = _rpg_def(story)
    quests_def = rpg_def.get('quests', {})
    rpg = (session.get('world_state') or {}).get('rpg')
    if not isinstance(rpg, dict) or not quests_def:
        return []
    notes = []
    for qid, qdef in quests_def.items():
        qstate = rpg['quests'].get(qid)
        if not qstate or qstate['status'] == 'completed':
            continue
        reqs = qdef.get('requires', [])
        if any(rpg['quests'].get(r, {}).get('status') != 'completed' for r in reqs):
            continue
        steps = qdef.get('steps', [])
        idx = int(qstate.get('step_index', 0))
        if idx >= len(steps):
            continue
        step = steps[idx]
        if step.get('kind') == trigger_kind and step.get('target') == target_id:
            if qstate['status'] == 'seed':
                qstate['status'] = 'active'
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            notes.append(f"任務進度更新（{qdef['name']}）：已完成「{step['label']}」。")
    return notes


def _segment_damage(atk_val, def_val, power, affinity):
    base = max(1, (int(atk_val) * int(power) // 100) - (int(def_val) // 2))
    if affinity == 'immune':
        return 0
    if affinity == 'weak':
        return int(base * 1.5)
    if affinity == 'resist':
        return max(1, int(base * 0.5))
    return base


def compute_skill_damage(actor_stats, enemy_def, enemy_state, element, power, compound_element=None):
    """Compute damage using exact Chapter 05 single or split-element formulas."""
    affinities = enemy_def.get('affinities', {})
    hit_weak = False
    if compound_element:
        p1 = int(power) // 2
        p2 = int(power) - p1
        segments = [(element, p1), (compound_element, p2)]
    else:
        segments = [(element, int(power))]
    total = 0
    for elem, seg_power in segments:
        is_magic = elem in MAGIC_ELEMENTS
        atk_val = actor_stats['magic'] if is_magic else actor_stats['attack']
        def_val = int(enemy_state['resist'] if is_magic else enemy_state['defense'])
        aff = affinities.get(elem, 'normal')
        if aff == 'weak':
            hit_weak = True
        total += _segment_damage(atk_val, def_val, seg_power, aff)
    if enemy_state.get('break_open') and total > 0:
        total = int(total * 1.5)
        enemy_state['break_open'] = False
        enemy_state['pressure'] = 0
    return total, hit_weak


def _apply_status_dot(actor):
    dots = [s for s in actor.get('statuses', []) if s in ('poison', 'burn', 'bleed')]
    if not dots:
        return 0
    dmg_each = max(1, int(actor['max_hp']) * 5 // 100)
    total = dmg_each * len(dots)
    actor['hp'] = max(0, int(actor['hp']) - total)
    return total


def _recover_arrows(session, rpg, outcome):
    quiver = rpg['quiver']
    spent = int(quiver.get('spent_this_encounter', 0))
    quiver['spent_this_encounter'] = 0
    if spent <= 0 or outcome == 'retreat':
        return 0
    scene_id = session.get('scene_id', '')
    region_id = ''
    for s in session.get('_scenes_cache', []):
        if s.get('id') == scene_id:
            region_id = s.get('region_id', '')
            break
    rate = 0.3 if (region_id in HARD_ENV_REGIONS or 'mine' in scene_id or 'crystal' in scene_id) else 0.7
    recovered = int(spent * rate)
    quiver['arrows'] = min(int(quiver.get('max_arrows', 12)), int(quiver.get('arrows', 0)) + recovered)
    return recovered


def handle_action(story, session, body):
    """Execute a structured RPG action and return a narrator message dict."""
    initialize(story, session)
    rpg_def = _rpg_def(story)
    if not rpg_def:
        raise engine.StoryError('此世界尚未載入 RPG 規則設定。')
    state = session['world_state']
    rpg = state['rpg']
    kind = body.get('action')
    scene_id = session['scene_id']
    scene = engine._scene(story, scene_id)
    party_ids = ['player'] + list(state.get('party_character_ids', []))

    if kind == 'rpg_rest':
        if rpg['encounters'].get('active'):
            raise engine.StoryError('遭遇進行中無法休整，請先結束遭遇或撤離。')
        if scene_id not in rpg_def.get('rest_scenes', []):
            raise engine.StoryError('只有安全據點（旅店、宿舍、公會、村莊或各區協調所）可以進行休整。')
        cost = 10
        if rpg['gold'] >= cost:
            rpg['gold'] -= cost
            debt_note = f'支付 {cost} 試玩幣'
        else:
            shortfall = cost - rpg['gold']
            rpg['gold'] = 0
            rpg['rescue_debt'] = int(rpg.get('rescue_debt', 0)) + shortfall
            debt_note = f'試玩幣不足，記求援費 {shortfall}（將於後續報酬優先償還）'
        for aid in party_ids:
            actor = rpg['actors'].get(aid)
            if not actor:
                continue
            actor['hp'] = actor['max_hp']
            actor['mp'] = actor['max_mp']
            actor['sp'] = actor['max_sp']
            actor['statuses'] = []
            actor['overload_streak'] = 0
        return f"於 {scene['title']} 完成安全休整（{debt_note}），同行隊伍 HP／MP／SP 與異常狀態已恢復。"

    if kind == 'rpg_change_job':
        if rpg['encounters'].get('active'):
            raise engine.StoryError('戰鬥遭遇中不可更換職業。')
        if scene_id not in rpg_def.get('training_scenes', []):
            raise engine.StoryError('請前往訓練據點（騎士團、競技場、公會、哨站、守衛區或各區議事庭）選修職業。')
        actor_id = body.get('actor_id') or 'player'
        if actor_id != 'player':
            raise engine.StoryError('同伴保留各自的能力方向，僅玩家可自由選修基礎職業。')
        player = rpg['actors']['player']
        if any(player['equipment'].values()):
            raise engine.StoryError('更換職業前須先卸下所有已裝備物品。')
        new_job = body.get('job') or body.get('job_id')
        if new_job not in BASE_JOBS:
            raise engine.StoryError('不支援的職業 ID。')
        player['job'] = new_job
        jobs_meta = (rpg_def.get('jobs') or {}).get('base_jobs', {}).get(new_job, {})
        branches = list((jobs_meta.get('specialist_branches') or {}).keys())
        adv_classes = list((jobs_meta.get('advanced_classes') or {}).keys())
        player['specialist_branch'] = body.get('specialist_branch') if body.get('specialist_branch') in branches else (branches[0] if branches else None)
        player['advanced_class'] = body.get('advanced_class') if body.get('advanced_class') in adv_classes else (adv_classes[0] if adv_classes else None)
        return f"已於 {scene['title']} 將職業切換為「{BASE_JOBS[new_job]['name']}」。"

    if kind == 'rpg_equip':
        actor_id = body.get('actor_id') or 'player'
        if actor_id not in rpg['actors'] or (actor_id != 'player' and actor_id not in state['party_character_ids']):
            raise engine.StoryError('只能為玩家本人或同行中的隊友調整裝備。')
        actor = rpg['actors'][actor_id]
        instance_id = body.get('instance_id')
        inst = next((x for x in rpg['inventory'] if x['instance_id'] == instance_id and not x.get('used')), None)
        if not inst:
            raise engine.StoryError('找不到這件物品實例。')
        if inst.get('equipped_by') and inst['equipped_by'] != actor_id:
            raise engine.StoryError('同一件物品實例不能同時裝備於兩名角色身上。')
        idef = rpg_def.get('items', {}).get(inst['item_id'], {})
        if idef.get('kind') != 'equipment':
            raise engine.StoryError('此物品不是可穿戴裝備。')
        allowed_jobs = idef.get('jobs') or []
        if allowed_jobs and actor['job'] not in allowed_jobs:
            raise engine.StoryError(f"此裝備僅限需要職業：{', '.join(allowed_jobs)}。")
        slot = body.get('slot') or idef.get('slot') or 'main'
        if slot == 'accessory2' and idef.get('slot') == 'accessory1':
            pass
        elif slot != idef.get('slot'):
            raise engine.StoryError('裝備欄位不符。')
        if slot == 'off':
            main_id = actor['equipment'].get('main')
            if main_id:
                main_inst = next((x for x in rpg['inventory'] if x['instance_id'] == main_id), None)
                main_def = rpg_def.get('items', {}).get(main_inst['item_id'], {}) if main_inst else {}
                if int(main_def.get('hands', 1)) == 2:
                    raise engine.StoryError('雙手武器占兩手，不能同時拿副手盾牌。')
        if int(idef.get('hands', 1)) == 2 and actor['equipment'].get('off'):
            off_id = actor['equipment']['off']
            off_inst = next((x for x in rpg['inventory'] if x['instance_id'] == off_id), None)
            if off_inst:
                off_inst['equipped_by'] = None
                off_inst['slot'] = None
            actor['equipment']['off'] = None
        old_id = actor['equipment'].get(slot)
        if old_id:
            old_inst = next((x for x in rpg['inventory'] if x['instance_id'] == old_id), None)
            if old_inst:
                old_inst['equipped_by'] = None
                old_inst['slot'] = None
        actor['equipment'][slot] = inst['instance_id']
        inst['equipped_by'] = actor_id
        inst['slot'] = slot
        return f"{actor['name']} 已裝備「{idef.get('name', inst['item_id'])}」（{slot}）。"

    if kind == 'rpg_unequip':
        actor_id = body.get('actor_id') or 'player'
        actor = rpg['actors'].get(actor_id)
        if not actor:
            raise engine.StoryError('找不到這名角色。')
        slot = body.get('slot')
        slots_to_clear = [slot] if slot in SLOTS else list(SLOTS)
        cleared = []
        for s in slots_to_clear:
            iid = actor['equipment'].get(s)
            if iid:
                inst = next((x for x in rpg['inventory'] if x['instance_id'] == iid), None)
                if inst:
                    inst['equipped_by'] = None
                    inst['slot'] = None
                    cleared.append(rpg_def.get('items', {}).get(inst['item_id'], {}).get('name', inst['item_id']))
                actor['equipment'][s] = None
        if not cleared:
            raise engine.StoryError('目前沒有可卸下的裝備。')
        return f"{actor['name']} 已卸下：{'、'.join(cleared)}。"

    if kind == 'rpg_use_item':
        instance_id = body.get('instance_id')
        item_id = body.get('item_id')
        inst = next((x for x in rpg['inventory'] if not x.get('used') and (
            (instance_id and x['instance_id'] == instance_id) or (not instance_id and x['item_id'] == item_id))), None)
        if not inst:
            raise engine.StoryError('背包中沒有可用的此類消耗品。')
        idef = rpg_def.get('items', {}).get(inst['item_id'], {})
        if idef.get('kind') != 'consumable':
            raise engine.StoryError('此物品不是消耗品。')
        target_id = body.get('target_id') or 'player'
        target = rpg['actors'].get(target_id)
        if not target:
            raise engine.StoryError('找不到目標角色。')
        if idef.get('heal'):
            if target['hp'] <= 0:
                raise engine.StoryError('0 HP 不能靠普通藥品或包紮復活，須結束遭遇後到安全據點求援。')
            target['hp'] = min(target['max_hp'], target['hp'] + int(idef['heal']))
            effect_text = f"{target['name']} 恢復 HP（目前 {target['hp']}／{target['max_hp']}）"
        elif idef.get('mana'):
            target['mp'] = min(target['max_mp'], target['mp'] + int(idef['mana']))
            effect_text = f"{target['name']} 恢復 MP（目前 {target['mp']}／{target['max_mp']}）"
        elif idef.get('stamina'):
            target['sp'] = min(target['max_sp'], target['sp'] + int(idef['stamina']))
            effect_text = f"{target['name']} 恢復 SP（目前 {target['sp']}／{target['max_sp']}）"
        elif idef.get('ammunition'):
            q = rpg['quiver']
            q['arrows'] = min(int(q.get('max_arrows', 12)), int(q.get('arrows', 0)) + int(idef['ammunition']))
            effect_text = f"補充箭筒箭矢（目前 {q['arrows']}／{q['max_arrows']} 支）"
        else:
            raise engine.StoryError('無法識別消耗品效果。')
        inst['used'] = True
        return f"已使用「{idef.get('name', inst['item_id'])}」：{effect_text}。"

    if kind in ('rpg_buy', 'rpg_craft', 'rpg_open_chest', 'rpg_steal'):
        source_id = body.get('source_id')
        src = rpg['sources'].get(source_id)
        if not src:
            raise engine.StoryError('找不到指定的商店、工坊或寶箱來源。')
        story_sids = {s['id'] for s in story.get('scenes', [])}
        if src.get('scene_id') and src['scene_id'] in story_sids and src['scene_id'] != scene_id:
            raise engine.StoryError('請先前往對應地點再進行此操作。')
        if src.get('region_id') and not src.get('scene_id') and src['region_id'] != scene.get('region_id'):
            if any(s.get('region_id') == src['region_id'] and s['id'] == scene_id for s in story.get('scenes', [])):
                raise engine.StoryError('請先前往該地區再向地方補給商採購。')

        if kind == 'rpg_open_chest':
            if src['kind'] != 'chest':
                raise engine.StoryError('此來源不是寶箱。')
            available = [r for r in src['stock'] if r.get('count', 1) > 0]
            if not available:
                raise engine.StoryError('這個鎖箱已經開啟過，不會因重開補貨。')
            has_thief = any(rpg['actors'][aid]['job'] == 'thief' for aid in party_ids if aid in rpg['actors'])
            key_item = src.get('key_item')
            key_inst = next((x for x in rpg['inventory'] if not x.get('used') and x['item_id'] == key_item), None) if key_item else None
            tool_inst = next((x for x in rpg['inventory'] if not x.get('used') and x['item_id'] == 'I16'), None)
            if src.get('locked') and not (key_inst or (has_thief and tool_inst) or has_thief):
                raise engine.StoryError('此鎖箱需要對應鑰匙（紫銅箱鑰匙）或盜賊開鎖專長。')
            if key_inst:
                key_inst['used'] = True
            row = available[0]
            row['count'] = 0
            src['locked'] = False
            _give_item(rpg, row['item_id'], source_id, 1)
            iname = rpg_def.get('items', {}).get(row['item_id'], {}).get('name', row['item_id'])
            return f"已開啟「{src['name']}」，取得「{iname}」。"

        item_id = body.get('item_id')
        row = next((r for r in src['stock'] if r['item_id'] == item_id and r.get('count', 1) > 0), None)
        if not row:
            raise engine.StoryError('該物品目前已無庫存。')
        idef = rpg_def.get('items', {}).get(item_id, {})

        if kind == 'rpg_steal':
            if not src.get('stealable'):
                raise engine.StoryError('此目標不支援指定偷取。')
            if src.get('stolen_attempted'):
                raise engine.StoryError('同一庫存不可反覆重擲偷取；對方已提高戒備。')
            has_thief = any(rpg['actors'][aid]['job'] == 'thief' for aid in party_ids if aid in rpg['actors'])
            if not has_thief:
                raise engine.StoryError('指定偷取需要玩家或同行同伴具備「盜賊」職業專長。')
            if item_id == 'I08' and rpg['encounters'].get('obsidian_sword_transferred'):
                raise engine.StoryError('黑曜長劍（I08）為唯一具名實例，已移轉後不會產生第二把。')
            src['stolen_attempted'] = True
            # Deterministic 65% check from event_id or explicit test roll
            roll = body.get('roll')
            if not isinstance(roll, (int, float)):
                digest = hashlib.sha256(str(body.get('event_id', '')).encode()).digest()
                roll = (digest[0] % 100) / 100.0
            if roll < 0.65:
                row['count'] -= 1
                if item_id == 'I08':
                    rpg['encounters']['obsidian_sword_transferred'] = True
                _give_item(rpg, item_id, source_id, 1)
                return f"指定偷取成功（判定 {roll:.2f} < 0.65）：已取得「{idef.get('name', item_id)}」。"
            src['alerted'] = True
            return f"指定偷取失敗（判定 {roll:.2f} >= 0.65）：已被發現並留下戒備記錄，同一庫存不可重擲。"

        if kind == 'rpg_craft':
            if src['kind'] != 'forge':
                raise engine.StoryError('此來源不是工匠委託。')
            req_quest = src.get('requires')
            if req_quest and rpg['quests'].get(req_quest, {}).get('status') != 'completed':
                raise engine.StoryError(f"需先完成任務 {req_quest} 才能解鎖此工匠委託。")
            price = int(row.get('price', 0))
            if rpg['gold'] < price:
                raise engine.StoryError(f"試玩幣不足（需要 {price}）。")
            mat_id = row.get('material')
            mat_inst = None
            if mat_id:
                mat_inst = next((x for x in rpg['inventory'] if not x.get('used') and x['item_id'] == mat_id), None)
                if not mat_inst:
                    mname = rpg_def.get('items', {}).get(mat_id, {}).get('name', mat_id)
                    raise engine.StoryError(f"缺少委託所需原器／材料：「{mname}」（{mat_id}）。")
            rpg['gold'] -= price
            if mat_inst:
                if mat_inst.get('equipped_by'):
                    owner = rpg['actors'].get(mat_inst['equipped_by'])
                    if owner and mat_inst.get('slot'):
                        owner['equipment'][mat_inst['slot']] = None
                    mat_inst['equipped_by'] = None
                    mat_inst['slot'] = None
                mat_inst['used'] = True
            row['count'] -= 1
            _give_item(rpg, item_id, source_id, 1)
            return f"已完成工匠委託鍛造：取得「{idef.get('name', item_id)}」（消耗 {price} 試玩幣" + (f"與原器 {mat_id}）。" if mat_id else "）。")

        # kind == 'rpg_buy'
        if src.get('alerted'):
            raise engine.StoryError('此商家因偷取失敗正處於戒備狀態，拒絕交易。')
        price = int(row.get('price', 0))
        if rpg['gold'] < price:
            raise engine.StoryError(f"試玩幣不足（需要 {price}）。")
        rpg['gold'] -= price
        row['count'] -= 1
        _give_item(rpg, item_id, source_id, 1)
        return f"已向「{src['name']}」購買「{idef.get('name', item_id)}」（花費 {price} 試玩幣，剩餘 {rpg['gold']}）。"

    if kind == 'rpg_start_encounter':
        if rpg['encounters'].get('active'):
            raise engine.StoryError('目前已有進行中的遭遇。')
        enemy_id = body.get('enemy_id')
        edef = rpg_def.get('enemies', {}).get(enemy_id)
        if not edef or not edef.get('enabled', True):
            raise engine.StoryError('找不到這名敵人或該遭遇尚未開放。')
        if not edef.get('repeatable', True):
            if enemy_id in rpg['encounters']['defeated_ids'] or enemy_id in rpg['encounters']['resolved_ids']:
                raise engine.StoryError('此非重複強敵／事件遭遇已完成，不可反覆刷取。')
        st = edef.get('stats', {})
        atk = int(st.get('attack', 15))
        if enemy_id == 'BOSS07' and rpg['encounters'].get('obsidian_sword_transferred'):
            atk = max(1, atk - 10)
        moves = edef.get('moves') or [{'name': '逼近攻擊', 'element': 'blunt', 'power': 100, 'precast_signal': '敵方逼近準備攻擊'}]
        rpg['encounters']['active'] = {
            'enemy_id': enemy_id,
            'name': edef['name'],
            'hp': int(st.get('hp', 80)),
            'max_hp': int(st.get('hp', 80)),
            'attack': atk,
            'defense': int(st.get('defense', 8)),
            'magic': int(st.get('magic', 12)),
            'resist': int(st.get('resist', 8)),
            'speed': int(st.get('speed', 10)),
            'phase': 1,
            'pressure': 0,
            'break_open': False,
            'move_index': 0,
            'next_move': moves[0],
        }
        rpg['quiver']['spent_this_encounter'] = 0
        return f"遭遇開始：【{edef['name']}】（HP {st.get('hp')}）｜前兆：{moves[0].get('precast_signal', '')}"

    if kind == 'rpg_combat':
        active = rpg['encounters'].get('active')
        if not active:
            raise engine.StoryError('目前沒有進行中的戰鬥遭遇。')
        enemy_id = active['enemy_id']
        edef = rpg_def.get('enemies', {})[enemy_id]
        actor_id = body.get('actor_id') or 'player'
        if actor_id not in party_ids or actor_id not in rpg['actors']:
            raise engine.StoryError('請選擇玩家或目前同行中的隊員執行行動。')
        actor = rpg['actors'][actor_id]
        if actor['hp'] <= 0:
            raise engine.StoryError(f"{actor['name']} 目前為 0 HP，無法行動。")
        astats = effective_stats(story, session, actor_id)
        move_kind = body.get('move') or 'attack'
        defended = False
        log_parts = []

        if move_kind == 'retreat':
            if actor['sp'] < 10:
                raise engine.StoryError('撤離需要消耗 10 點精力（SP）。')
            actor['sp'] -= 10
            if astats['speed'] < active['speed']:
                emove = active.get('next_move') or {'name': '追擊', 'element': 'blunt', 'power': 100}
                is_mag = emove.get('element') in MAGIC_ELEMENTS
                e_atk = active['magic'] if is_mag else active['attack']
                p_def = astats['resist'] if is_mag else astats['defense']
                rdmg = max(1, (e_atk * int(emove.get('power', 100)) // 100) - (p_def // 2))
                if active.get('phase') == 2:
                    rdmg = int(rdmg * 1.2)
                actor['hp'] = max(0, actor['hp'] - rdmg)
                log_parts.append(f"撤離時因速度較慢承受已預告攻勢「{emove['name']}」（-{rdmg} HP）")
            _recover_arrows(session, rpg, 'retreat')
            rpg['encounters']['active'] = None
            log_parts.append('隊伍已撤離遭遇現場（傷勢與已耗資源保留，撤離不回收箭矢）。')
            return '；'.join(log_parts)

        if move_kind == 'resolve':
            res_id = body.get('resolution_id')
            res_list = edef.get('resolutions') or []
            res = next((r for r in res_list if r['id'] == res_id), res_list[0] if res_list else None)
            if not res:
                raise engine.StoryError('此遭遇沒有可用的非戰鬥處置方案。')
            req_job = res.get('job')
            if req_job and not any(rpg['actors'][aid]['job'] == req_job for aid in party_ids if aid in rpg['actors']):
                raise engine.StoryError(f"此非戰鬥處置方案需要隊伍具備「{BASE_JOBS.get(req_job, {}).get('name', req_job)}」職業。")
            sp_need = 20 if enemy_id in ('WB01', 'WB02') else 15
            if actor['sp'] < sp_need:
                raise engine.StoryError(f"執行此非戰鬥處置需要 {sp_need} 點精力（SP）。")
            actor['sp'] -= sp_need
            if enemy_id not in rpg['encounters']['resolved_ids']:
                rpg['encounters']['resolved_ids'].append(enemy_id)
            rec = _recover_arrows(session, rpg, 'resolve')
            rpg['encounters']['active'] = None
            rw = (edef.get('rewards') or {}).get('resolve', {'xp': 30, 'items': []})
            leveled = _award_xp(rpg, party_ids, rw.get('xp', 0))
            loot_names = []
            if enemy_id not in rpg['encounters']['looted_ids']:
                rpg['encounters']['looted_ids'].append(enemy_id)
                for item_entry in rw.get('items', []):
                    iid = item_entry['item_id']
                    if iid == 'I08' and rpg['encounters'].get('obsidian_sword_transferred'):
                        continue
                    if iid == 'I08':
                        rpg['encounters']['obsidian_sword_transferred'] = True
                    _give_item(rpg, iid, enemy_id, 1)
                    loot_names.append(rpg_def.get('items', {}).get(iid, {}).get('name', iid))
            qnotes = sync_quest_progress(story, session, 'encounter', enemy_id)
            msg = f"{actor['name']} 執行非戰鬥處置「{res['label']}」成功！獲得 {rw.get('xp', 0)} XP"
            if loot_names:
                msg += f"，取得物品：{'、'.join(loot_names)}"
            if rec:
                msg += f"，戰後回收箭矢 {rec} 支"
            if leveled:
                msg += f"，升級：{', '.join(f'{n} Lv.{lv}' for n, lv in leveled)}"
            if qnotes:
                msg += "。" + " ".join(qnotes)
            return msg + "。"

        if move_kind == 'defend':
            defended = True
            actor['sp'] = min(actor['max_sp'], actor['sp'] + 10)
            actor['overload_streak'] = 0
            if 'overloaded' in actor['statuses']:
                actor['statuses'].remove('overloaded')
            active['pressure'] = int(active.get('pressure', 0)) + 1
            if active['pressure'] >= 3:
                active['break_open'] = True
            log_parts.append(f"{actor['name']} 採取防守姿態（SP+10，本回隊伍承受反應傷害減半，敵方壓力 {active['pressure']}/3）")
        elif move_kind in ('attack', 'job_skill', 'advanced_skill', 'signature_skill'):
            element = astats['main_element']
            compound_element = None
            power = 100
            sp_cost = 0
            mp_cost = 0
            ammo_cost = 0
            skill_label = '普通攻擊'
            is_heal = False
            pressure_bonus = 0

            # Check bow ammunition for basic hunter bow attacks
            main_id = actor['equipment'].get('main')
            if main_id:
                main_inst = next((x for x in rpg['inventory'] if x['instance_id'] == main_id), None)
                if main_inst and main_inst['item_id'] == 'I04' and move_kind in ('attack', 'job_skill', 'advanced_skill'):
                    ammo_cost = 1

            if move_kind in ('job_skill', 'advanced_skill'):
                jinfo = BASE_JOBS[actor['job']]
                if move_kind == 'advanced_skill' and not (actor.get('level', 1) >= 3 or actor.get('advanced_unlocked')):
                    raise engine.StoryError('Lv.3 以上或解鎖進階職後才可使用進階專長（220%）。')
                if actor['sp'] < 20 and jinfo['sp_cost'] > 0:
                    raise engine.StoryError('SP 低於 20 不可使用耗精力的高強度技能。')
                power = 220 if move_kind == 'advanced_skill' else jinfo['power']
                sp_cost = jinfo['sp_cost'] + (8 if move_kind == 'advanced_skill' and jinfo['sp_cost'] > 0 else 0)
                mp_cost = jinfo['mp_cost'] + (8 if move_kind == 'advanced_skill' and jinfo['mp_cost'] > 0 else 0)
                element = (actor['skill_elements'][0] if actor.get('skill_elements') and actor['job'] == 'scholar' else jinfo['element'])
                if move_kind == 'advanced_skill' and actor.get('advanced_class') == 'spellblade':
                    element = 'slash'
                    compound_element = 'magic'
                    skill_label = '魔劍士進階技：附刃破陣斬'
                else:
                    skill_label = f"{jinfo['name']}{'進階專長' if move_kind == 'advanced_skill' else '基礎專長'}"
                is_heal = jinfo['kind'] == 'heal'
            elif move_kind == 'signature_skill':
                skill_id = body.get('skill_id')
                adef = rpg_def.get('actors', {}).get(actor_id, {})
                sig_list = adef.get('signature_skills') or []
                sig = next((s for s in sig_list if s['id'] == skill_id), sig_list[0] if sig_list else None)
                if not sig:
                    raise engine.StoryError('此角色沒有指定的專屬招式。')
                if sig.get('category') in ('innate', 'trait') or int(sig.get('power', 0)) == 0 and sig.get('category') == 'field':
                    raise engine.StoryError('被動固有特性或非戰鬥場域技能不直接作為戰鬥攻擊施放。')
                if sig['id'] == 'char_07_lord_s2':
                    has_i08 = any(
                        next((x for x in rpg['inventory'] if x['instance_id'] == iid), {}).get('item_id') == 'I08'
                        for iid in (actor.get('equipment') or {}).values() if iid
                    )
                    if rpg['encounters'].get('obsidian_sword_transferred') and not has_i08:
                        raise engine.StoryError('失去黑曜長劍（I08）後不可使用「黑曜纏刃」。')
                if 'overloaded' in actor.get('statuses', []):
                    raise engine.StoryError('目前處於「過載顫抖」狀態，精密施法受限；請先採取防守調息或休整。')
                sp_cost = int(sig.get('sp_cost', 0))
                mp_cost = int(sig.get('mp_cost', 0))
                ammo_cost = int(sig.get('ammunition_cost', 0))
                if actor['sp'] < 20 and sp_cost >= 10:
                    raise engine.StoryError('SP 低於 20 不可使用耗精力的高強度技能。')
                power = int(sig.get('power', 150))
                element = sig.get('element', 'slash')
                compound_element = sig.get('compound_element')
                skill_label = sig['name']
                is_heal = element == 'heal'
                if '施壓+2' in sig.get('effect', ''):
                    pressure_bonus = 2
                elif '施壓+1' in sig.get('effect', ''):
                    pressure_bonus = 1

            if mp_cost > 0 and 'silence' in actor.get('statuses', []):
                raise engine.StoryError('處於「沉默」狀態，無法施展魔法技能。')
            if actor['sp'] < sp_cost:
                raise engine.StoryError(f"精力（SP）不足（需要 {sp_cost}，目前 {actor['sp']}）。")
            if actor['mp'] < mp_cost:
                raise engine.StoryError(f"魔力（MP）不足（需要 {mp_cost}，目前 {actor['mp']}）。")
            if ammo_cost > 0 and int(rpg['quiver'].get('arrows', 0)) < ammo_cost:
                raise engine.StoryError('箭筒中已無箭矢，請先補充普通箭矢束或改用其他行動。')

            actor['sp'] -= sp_cost
            actor['mp'] -= mp_cost
            if ammo_cost > 0:
                rpg['quiver']['arrows'] -= ammo_cost
                rpg['quiver']['spent_this_encounter'] = int(rpg['quiver'].get('spent_this_encounter', 0)) + ammo_cost

            if actor_id == 'char_02_trouble' and move_kind == 'signature_skill':
                actor['overload_streak'] = int(actor.get('overload_streak', 0)) + 1
                q_done = rpg['quests'].get('Q02-03', {}).get('status') == 'completed'
                if actor['overload_streak'] >= (3 if q_done else 2):
                    if 'overloaded' not in actor['statuses']:
                        actor['statuses'].append('overloaded')

            if is_heal and 'heal' not in (edef.get('affinities') or {}):
                heal_amt = max(15, astats['magic'] * power // 100)
                target_id = body.get('target_id') or actor_id
                target = rpg['actors'].get(target_id, actor)
                if target['hp'] <= 0:
                    raise engine.StoryError('0 HP 不能靠治療術或包紮直接復活，須結束遭遇後到安全據點求援。')
                target['hp'] = min(target['max_hp'], target['hp'] + heal_amt)
                for cured in ('poison', 'burn', 'bleed'):
                    if cured in target['statuses']:
                        target['statuses'].remove(cured)
                        break
                log_parts.append(f"{actor['name']} 施展「{skill_label}」，為 {target['name']} 恢復 {heal_amt} HP（目前 {target['hp']}／{target['max_hp']}）")
            else:
                dmg, hit_weak = compute_skill_damage(astats, edef, active, element, power, compound_element)
                active['hp'] = max(0, active['hp'] - dmg)
                p_gain = 2 if hit_weak else pressure_bonus
                if p_gain > 0:
                    active['pressure'] = int(active.get('pressure', 0)) + p_gain
                    if active['pressure'] >= 3:
                        active['break_open'] = True
                log_parts.append(
                    f"{actor['name']} 使用「{skill_label}」對 {active['name']} 造成 {dmg} 點傷害"
                    + ("（命中弱點！施壓+2）" if hit_weak else "")
                    + f"（敵方 HP {active['hp']}／{active['max_hp']}）"
                )
        else:
            raise engine.StoryError('不支援的戰鬥指令。')

        dot_dmg = _apply_status_dot(actor)
        if dot_dmg > 0:
            log_parts.append(f"{actor['name']} 受持續異常狀態影響損失 {dot_dmg} HP")

        if active['hp'] <= 0:
            if enemy_id not in rpg['encounters']['defeated_ids']:
                rpg['encounters']['defeated_ids'].append(enemy_id)
            rec = _recover_arrows(session, rpg, 'victory')
            rpg['encounters']['active'] = None
            rw = (edef.get('rewards') or {}).get('victory', {'xp': 30, 'items': []})
            leveled = _award_xp(rpg, party_ids, rw.get('xp', 0))
            loot_names = []
            if enemy_id not in rpg['encounters']['looted_ids']:
                rpg['encounters']['looted_ids'].append(enemy_id)
                for idx, item_entry in enumerate(rw.get('items', [])):
                    chance = int(item_entry.get('chance', 100))
                    if chance < 100:
                        digest = hashlib.sha256(f"{body.get('event_id', '')}:{idx}".encode()).digest()
                        if (digest[0] % 100) >= chance:
                            continue
                    iid = item_entry['item_id']
                    if iid == 'I08' and rpg['encounters'].get('obsidian_sword_transferred'):
                        continue
                    if iid == 'I08':
                        rpg['encounters']['obsidian_sword_transferred'] = True
                    _give_item(rpg, iid, enemy_id, 1)
                    loot_names.append(rpg_def.get('items', {}).get(iid, {}).get('name', iid))
            qnotes = sync_quest_progress(story, session, 'encounter', enemy_id)
            log_parts.append(f"擊退【{edef['name']}】！獲得 {rw.get('xp', 0)} XP")
            if loot_names:
                log_parts.append(f"取得戰利品：{'、'.join(loot_names)}")
            if rec:
                log_parts.append(f"戰後回收箭矢 {rec} 支")
            if leveled:
                log_parts.append(f"升級：{', '.join(f'{n} Lv.{lv}' for n, lv in leveled)}")
            if qnotes:
                log_parts.extend(qnotes)
            return '；'.join(log_parts) + '。'

        if active['hp'] <= active['max_hp'] // 2 and active.get('phase', 1) == 1:
            active['phase'] = 2
            log_parts.append(f"【{active['name']}】HP 降至一半以下，進入第二階段（反應傷害×1.2）")

        moves = edef.get('moves') or [{'name': '反擊', 'element': 'blunt', 'power': 100, 'precast_signal': '敵方準備下一波攻勢'}]
        emove = active.get('next_move') or moves[0]
        is_mag = emove.get('element') in MAGIC_ELEMENTS
        e_atk = active['magic'] if is_mag else active['attack']
        p_def = astats['resist'] if is_mag else astats['defense']
        rdmg = max(1, (e_atk * int(emove.get('power', 100)) // 100) - (p_def // 2))
        if active.get('phase') == 2:
            rdmg = int(rdmg * 1.2)
        if defended:
            rdmg = max(1, rdmg // 2)
        actor['hp'] = max(0, actor['hp'] - rdmg)
        next_idx = (int(active.get('move_index', 0)) + 1) % len(moves)
        active['move_index'] = next_idx
        active['next_move'] = moves[next_idx]
        log_parts.append(
            f"敵方反應「{emove['name']}」對 {actor['name']} 造成 {rdmg} 點傷害（剩餘 HP {actor['hp']}／{actor['max_hp']}）"
            f"｜下一波前兆：{active['next_move'].get('precast_signal', '')}"
        )
        return '；'.join(log_parts) + '。'

    if kind == 'rpg_quest':
        quest_id = body.get('quest_id')
        qdef = rpg_def.get('quests', {}).get(quest_id)
        if not qdef:
            raise engine.StoryError('找不到這項任務。')
        qstate = rpg['quests'][quest_id]
        if qstate['status'] == 'completed':
            raise engine.StoryError('此任務已結算完成，不可重複領獎。')
        reqs = qdef.get('requires', [])
        if any(rpg['quests'].get(r, {}).get('status') != 'completed' for r in reqs):
            raise engine.StoryError(f"需先完成前置任務：{', '.join(reqs)}。")
        if qstate['status'] == 'seed':
            qstate['status'] = 'active'
            if body.get('subaction') == 'start':
                # Also auto-check if step 0 is a visit to the current scene
                sync_quest_progress(story, session, 'visit', scene_id)
                return f"已啟動任務【{qdef['name']}】。"
        steps = qdef.get('steps', [])
        idx = int(qstate.get('step_index', 0))
        if idx >= len(steps):
            raise engine.StoryError('此任務所有步驟已完成。')
        step = steps[idx]
        skind = step.get('kind')
        if skind == 'visit':
            if scene_id != step.get('target'):
                raise engine.StoryError(f"請先前往任務目標地點：{step.get('label')}。")
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            return f"任務【{qdef['name']}】完成步驟：{step['label']}。"
        if skind == 'talk':
            target_cid = step.get('target')
            if target_cid not in session.get('cast', []):
                raise engine.StoryError(f"請先確認目標角色在場並與其對話：{step.get('label')}。")
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            return f"任務【{qdef['name']}】完成對話核對：{step['label']}。"
        if skind == 'investigate':
            if step.get('scene_id') and step['scene_id'] != scene_id:
                raise engine.StoryError('請先前往對應任務地點再進行現場調查。')
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            return f"任務【{qdef['name']}】完成調查：{step['label']}。"
        if skind == 'encounter':
            target_enemy = step.get('target')
            if target_enemy not in rpg['encounters']['defeated_ids'] and target_enemy not in rpg['encounters']['resolved_ids']:
                raise engine.StoryError(f"請先完成遭遇目標（{target_enemy}）：{step.get('label')}。")
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            return f"任務【{qdef['name']}】已確認解除現場危險：{step['label']}。"
        if skind == 'choose':
            if step.get('scene_id') and step['scene_id'] != scene_id:
                raise engine.StoryError('請在任務指定地點做出後續處理選擇。')
            option_id = body.get('option_id')
            opt = next((o for o in step.get('options', []) if o['id'] == option_id), None)
            if not opt:
                raise engine.StoryError('請選擇有效的任務處理分支（a 或 b）。')
            qstate['completed_steps'].append(idx)
            qstate['step_index'] = idx + 1
            qstate['choice'] = opt['id']
            qstate['consequence'] = opt['consequence']
            qstate['status'] = 'completed'
            rw = qdef.get('reward', {'xp': 60, 'gold': 25, 'items': []})
            leveled = []
            net_gold, repaid = 0, 0
            loot_names = []
            if not qstate.get('reward_claimed'):
                qstate['reward_claimed'] = True
                leveled = _award_xp(rpg, party_ids, rw.get('xp', 0))
                net_gold, repaid = _award_gold(rpg, rw.get('gold', 0))
                for item_entry in rw.get('items', []):
                    iid = item_entry['item_id']
                    _give_item(rpg, iid, quest_id, 1)
                    loot_names.append(rpg_def.get('items', {}).get(iid, {}).get('name', iid))
            msg = f"任務【{qdef['name']}】完成！選擇「{opt['label']}」→ {opt['consequence']}｜結算獎勵：{rw.get('xp', 0)} XP、{net_gold} 試玩幣"
            if repaid:
                msg += f"（已優先償還求援費 {repaid}）"
            if loot_names:
                msg += f"、物品：{'、'.join(loot_names)}"
            if leveled:
                msg += f"｜升級：{', '.join(f'{n} Lv.{lv}' for n, lv in leveled)}"
            return msg + "。"

    raise engine.StoryError('不支援的 RPG 操作。')
