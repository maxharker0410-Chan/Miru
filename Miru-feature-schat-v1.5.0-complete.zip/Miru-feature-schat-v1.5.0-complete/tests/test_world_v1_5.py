"""Comprehensive tests for S.Chat Magic World V1.5.0 Complete Implementation."""
import copy
from io import BytesIO
import pytest

import story_engine as engine
import world_import
import world_release
import world_rpg
import world_runtime
import world_settings
from test_world_import import archive, packages
from test_world_settings import authored, document


def test_v1_5_bundled_release_installs_regions_scenes_npcs_and_preserves_docx_compat(authored):
    root, story, session = authored
    res = world_release.install_bundled(root, story['id'], '')
    updated = res['story']
    assert updated['world']['content_release']['content_version'] == '1.5.0-complete.1'
    # 7 original + 4 expansion regions = 11
    region_ids = {r['id'] for r in updated['world']['definition']['regions']}
    assert {'region_08', 'region_09', 'region_10', 'region_11'}.issubset(region_ids)
    # 54 important + 99 original NPCs + 4 liaison NPCs = 157
    assert len(updated['characters']) == 157
    assert {'npc_08_liaison', 'npc_09_liaison', 'npc_10_liaison', 'npc_11_liaison'}.issubset(
        {c['id'] for c in updated['characters']}
    )
    # All 12 expansion scenes exist
    scene_ids = {s['id'] for s in updated['scenes']}
    for sid in (
        'loc_08_boundary_well', 'loc_08_winter_camp', 'loc_08_oath_stones',
        'loc_09_oath_hall', 'loc_09_crystal_fall', 'loc_09_memory_terrace',
        'loc_10_caravan_checkpoint', 'loc_10_dry_canal', 'loc_10_neutral_court',
        'loc_11_consent_house', 'loc_11_echo_archive', 'loc_11_dawn_council',
    ):
        assert sid in scene_ids

    # Verify DOCX update still succeeds when 4 liaison NPCs and 4 new regions are present
    docx_res = world_settings.apply_document(root, story['id'], document(story), 0)
    assert len(docx_res['story']['characters']) == 157


def test_v1_5_rpg_combat_compound_elements_quiver_market_and_quests(authored):
    root, story, session = authored
    story = world_release.install_bundled(root, story['id'], '')['story']
    session = engine.get_session(root, story['id'], session['id'])
    world_runtime.initialize(story, session)
    engine._write(engine._session_path(root, story['id'], session['id']), session)

    rpg = session['world_state']['rpg']
    assert len(rpg['actors']) == 55  # player + 54 important characters
    assert len(rpg['quests']) == 47
    assert rpg['quiver']['arrows'] == 12

    def act(action_name, **kwargs):
        cur = engine.get_session(root, story['id'], session['id'])
        rev = cur['world_state']['revision']
        return world_runtime.action(root, story['id'], session['id'], {
            'action': action_name,
            'event_id': f'ev_{rev}_{action_name}',
            'base_revision': rev,
            **kwargs
        })

    # 1. Buy 2-handed bow (I04) & shield (BASIC_SHIELD) -> verify 2-handed blocks shield
    session = act('rpg_buy', source_id='forest_bow', item_id='I04')
    session = act('rpg_buy', source_id='capital_smith', item_id='BASIC_SHIELD')
    inv = session['world_state']['rpg']['inventory']
    bow_inst = next(x for x in inv if x['item_id'] == 'I04')['instance_id']
    shd_inst = next(x for x in inv if x['item_id'] == 'BASIC_SHIELD')['instance_id']

    # Cannot equip hunter-only bow as warrior
    with pytest.raises(engine.StoryError, match='僅限'):
        act('rpg_equip', actor_id='player', instance_id=bow_inst)

    # Change job to hunter (while unequipped)
    session = act('rpg_change_job', actor_id='player', job_id='hunter')
    assert session['world_state']['rpg']['actors']['player']['job'] == 'hunter'

    # Equip bow, then verify equipping shield clears 2-handed main weapon or vice versa
    session = act('rpg_equip', actor_id='player', instance_id=shd_inst)
    assert session['world_state']['rpg']['actors']['player']['equipment']['off'] == shd_inst
    session = act('rpg_equip', actor_id='player', instance_id=bow_inst)
    assert session['world_state']['rpg']['actors']['player']['equipment']['main'] == bow_inst
    assert session['world_state']['rpg']['actors']['player']['equipment']['off'] is None

    # Cannot change job while equipped
    with pytest.raises(engine.StoryError, match='先卸下所有已裝備物品'):
        act('rpg_change_job', actor_id='player', job_id='warrior')

    # 2. Invite Lufia (char_05_archer) and Rayn (char_02_trouble) to party
    session = act('arrive', character_id='char_05_archer')
    session = act('join', character_id='char_05_archer')
    session = act('arrive', character_id='char_02_trouble')
    session = act('join', character_id='char_02_trouble')

    # 3. Start encounter with MOB02 (weak to pierce & wind) and test Lufia's compound skill (風引偏矢)
    session = act('rpg_start_encounter', enemy_id='MOB02')
    assert session['world_state']['rpg']['encounters']['active']['enemy_id'] == 'MOB02'
    arrows_before = session['world_state']['rpg']['quiver']['arrows']
    session = act('rpg_combat', actor_id='char_05_archer', move='signature_skill', skill_id='char_05_archer_s2')
    # MOB02 HP is 60; Lufia's compound pierce(100%)+wind(70%) deals 37 + 13 = 50 damage, leaving 10 HP
    assert session['world_state']['rpg']['encounters']['active']['hp'] == 12
    session = act('rpg_combat', actor_id='char_05_archer', move='signature_skill', skill_id='char_05_archer_s1')
    # 2 arrows spent total, 70% of 2 floored = 1 arrow recovered -> net arrows_before - 1
    assert 'MOB02' in session['world_state']['rpg']['encounters']['defeated_ids']
    assert session['world_state']['rpg']['quiver']['arrows'] == arrows_before - 1

    # 4. Test world boss WB01 and non-combat resolution
    session = act('rpg_change_job', actor_id='player', job_id='merchant') if False else session
    # Unequip bow, switch player to scholar, and resolve WB01
    session = act('rpg_unequip', actor_id='player', slot='main')
    session = act('rpg_change_job', actor_id='player', job_id='scholar')
    session = act('rpg_start_encounter', enemy_id='WB01')
    session = act('rpg_combat', actor_id='player', move='resolve', resolution_id='divert_load')
    assert 'WB01' in session['world_state']['rpg']['encounters']['resolved_ids']
    # WB01 resolve gives 240 XP -> player levels up to Lv.3!
    assert session['world_state']['rpg']['actors']['player']['level'] == 3

    # 5. Test 16-tick periodic supply shop restock
    session = act('rpg_buy', source_id='supplies_region_01', item_id='MEDICINE')
    stock_after_buy = next(
        r['count'] for r in session['world_state']['rpg']['sources']['supplies_region_01']['stock']
        if r['item_id'] == 'MEDICINE'
    )
    assert stock_after_buy == 2
    # Advance world_tick by 16 and trigger an action to verify auto-restock
    session['world_state']['world_tick'] += 16
    engine._write(engine._session_path(root, story['id'], session['id']), session)
    session = act('rpg_rest')
    stock_after_restock = next(
        r['count'] for r in session['world_state']['rpg']['sources']['supplies_region_01']['stock']
        if r['item_id'] == 'MEDICINE'
    )
    assert stock_after_restock == 3

    # 6. Test Quest Q08-01 in expansion region_08 (visit -> investigate -> choose)
    session = act('travel', location_id='loc_08_boundary_well')
    assert session['world_state']['rpg']['quests']['Q08-01']['status'] == 'active'
    assert session['world_state']['rpg']['quests']['Q08-01']['step_index'] == 1
    session = act('rpg_quest', quest_id='Q08-01')  # investigate step
    assert session['world_state']['rpg']['quests']['Q08-01']['step_index'] == 2
    gold_before = session['world_state']['rpg']['gold']
    session = act('rpg_quest', quest_id='Q08-01', option_id='a')  # choose step
    assert session['world_state']['rpg']['quests']['Q08-01']['status'] == 'completed'
    assert session['world_state']['rpg']['gold'] == gold_before + 25
