# S.Chat 互動故事工作台｜《魔法異世界》V1.5.0（完整實作版）

本專案為純淨版 **S.Chat 互動故事與 RPG 遊戲引擎**（已移除舊版桌寵、陪伴系統、Tauri 桌面殼與手機端模組），專注提供 S.Chat 故事創作工作台與《魔法異世界》全大陸共通世界書 **V1.5.0 (`1.5.0-complete.1`)** 完整前後端運作環境。

## 核心模組架構

- **伺服器與路由入口**
  - `app.py`：Flask 伺服器，提供 `/s-chat` 工作台與遊玩介面、`/login` 邀請碼與模型設定、`/api/schat/*` 故事與世界操作 API。
  - `auth.py`、`ai_config.py`、`owner_config.py`：帳號驗證、邀請碼管理與 OpenAI 相容聊天模型連線設定。
  - `tools/invite_cli.py`：管理員邀請碼產生與帳號管理 CLI 工具（`python -m tools.invite_cli new`）。
- **S.Chat 故事與《魔法異世界》V1.5.0 引擎**
  - `story_engine.py`、`story_tracker.py`：多角色視角隔離記憶、出場管理、立繪狀態切換與自訂數值追蹤器。
  - `world_runtime.py`、`world_rpg.py`：V1.5.0 八大基礎職業、專精分支與進階職業轉職、54 位重要角色專屬招式（`signature_skills`）、52 個敵人獨特招式與前兆、複合元素雙段判定、普通箭矢束（`ARROWS`）戰後按環境比例向下取整回收、11 區自由市場每 16 `world_tick` 周期補貨與同行上限（4 人）檢查。
  - `world_import.py`、`world_release.py`、`world_settings.py`、`world_memory.py`：世界資料包匯入、雲端內建 `1.5.0-complete.1` 一鍵套用（`cloud/world-release.json`）、Word `.docx` 設定書免重匯圖片熱更新與三層記憶整合。
- **前端介面與 PWA 資源**
  - `templates/s-chat.html`、`templates/login.html`、`templates/privacy.html`
  - `assets/js/schat.js`、`assets/js/schat-library.js`
  - `assets/brand/schat-icon.png`、`assets/brand/schat-pwa-192.png`、`assets/brand/schat-pwa-512.png`、`assets/brand/schat.ico`
  - `schat-manifest.json`、`schat-service-worker.js`

## 快速啟動

```bash
pip install -r requirements.txt
python app.py
```

啟動後於瀏覽器開啟 `http://127.0.0.1:5001/s-chat`（或透過 `http://127.0.0.1:5001/login` 進入本機單機模式並設定聊天模型 API）。

## 執行自動化測試

```bash
pytest -q
node --test tests/schat_library_checks.cjs tests/schat_speech_checks.cjs
```
