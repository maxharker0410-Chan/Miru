"""Install versioned author content without overwriting saves or credentials."""
import copy
import hashlib
import json
from pathlib import Path
import re
import story_engine as engine

MAX_RELEASE = 8 * 1024 * 1024
BUNDLED_WORLD_RELEASE = Path(__file__).resolve().parent / 'cloud' / 'world-release.json'
DIRECTION_KEYS = {
    'role', 'skills', 'limits', 'status',
    'specialist_branch', 'advanced_class', 'independent_module', 'signature_skills'
}


def validate(content, character_ids):
    if (not isinstance(content, dict) or content.get('schema_version') != '1.0.0'
            or content.get('world_id') != 'world_magic_isekai'
            or not isinstance(content.get('content_version'), str)
            or not re.fullmatch(r'\d+\.\d+\.\d+(?:-[a-z0-9.]+)?', content['content_version'])):
        raise engine.StoryError('新版設定的世界或版本格式不符。')
    rules = content.get('runtime_rules', {})
    if (not isinstance(rules, dict) or rules.get('party_limit') != 4
            or rules.get('memory_interval') != 8 or rules.get('memory_min') != 5
            or rules.get('memory_max') != 10 or rules.get('large_active_portrait') is not True):
        raise engine.StoryError('新版設定必須保留四位同行、大型立繪與 5～10 次記憶規則。')
    directions = content.get('character_directions')
    if not isinstance(directions, dict) or set(directions) != set(character_ids):
        raise engine.StoryError('新版能力方向必須與全部重要角色 ID 一致。')
    for value in directions.values():
        if not isinstance(value, dict) or set(value) - DIRECTION_KEYS:
            raise engine.StoryError('人物能力欄位格式錯誤。')
        if (not isinstance(value.get('role'), str) or len(value['role']) > 120
                or not isinstance(value.get('skills'), list) or len(value['skills']) > 6
                or any(not isinstance(x, str) or len(x) > 500 for x in value['skills'])
                or not isinstance(value.get('limits'), str) or len(value['limits']) > 1000):
            raise engine.StoryError('人物能力內容過長或不完整。')
    for key in ('quests', 'enemies', 'items'):
        records = content.get(key)
        if not isinstance(records, list) or len(records) > 200:
            raise engine.StoryError('新版設定的目錄格式錯誤。')
        seen = set()
        for item in records:
            if not isinstance(item, dict):
                raise engine.StoryError('新版設定目錄條目不完整。')
            ident = engine._id(item.get('id'))
            if ident in seen or not isinstance(item.get('text'), str) or len(item['text']) > 18000:
                raise engine.StoryError('新版設定目錄 ID 重複或內容過長。')
            seen.add(ident)
    if 'rpg' in content:
        rpg = content['rpg']
        if (not isinstance(rpg, dict)
                or not isinstance(rpg.get('actors'), dict)
                or not isinstance(rpg.get('quests'), dict)
                or not isinstance(rpg.get('enemies'), dict)
                or not isinstance(rpg.get('items'), dict)):
            raise engine.StoryError('新版 RPG 數值結構不完整。')
    if len(json.dumps(content, ensure_ascii=False).encode()) > 4 * 1024 * 1024:
        raise engine.StoryError('新版設定索引超過容量上限。')
    return copy.deepcopy(content)


def apply_expansion(story, expansion):
    """Safely merge expansion regions, scenes, and liaison NPCs without altering existing IDs."""
    if not isinstance(expansion, dict) or not story.get('world'):
        return story
    world_def = story['world']['definition']
    existing_regions = {r['id'] for r in world_def.get('regions', [])}
    for region in expansion.get('regions', []):
        if isinstance(region, dict) and region.get('id') and region['id'] not in existing_regions:
            world_def['regions'].append({'id': region['id'], 'name': region['name']})
            existing_regions.add(region['id'])

    existing_char_ids = {c['id'] for c in story['characters']}
    for npc in expansion.get('npcs', []):
        if isinstance(npc, dict) and npc.get('id') and npc['id'] not in existing_char_ids:
            npc_copy = copy.deepcopy(npc)
            npc_copy.setdefault('identity', {})
            npc_copy['identity'].setdefault('home_region_id', npc_copy.get('region_id'))
            story['characters'].append(npc_copy)
            existing_char_ids.add(npc_copy['id'])

    def_locs = {loc['id']: loc for loc in world_def.get('locations', [])}
    world_locs = {loc['id']: loc for loc in story['world'].setdefault('locations', [])}
    existing_scenes = {s['id']: s for s in story['scenes']}
    touched_regions = set()

    for scene in expansion.get('scenes', []):
        if not isinstance(scene, dict) or not scene.get('id'):
            continue
        sid = scene['id']
        rid = scene.get('region_id')
        touched_regions.add(rid)
        loc_entry = {
            'id': sid,
            'name': scene.get('title', sid),
            'region_id': rid,
            'parent_location_id': None,
            'record_status': 'release_scene'
        }
        if sid not in def_locs:
            world_def['locations'].append(copy.deepcopy(loc_entry))
            def_locs[sid] = loc_entry
        if sid not in world_locs:
            story['world']['locations'].append(copy.deepcopy(loc_entry))
            world_locs[sid] = loc_entry
        valid_cast = [cid for cid in scene.get('cast', []) if cid in existing_char_ids]
        if sid not in existing_scenes:
            sc_copy = {
                'id': sid,
                'title': scene.get('title', sid),
                'description': scene.get('description', ''),
                'background': scene.get('background', ''),
                'cast': valid_cast,
                'next': [],
                'region_id': rid or ''
            }
            story['scenes'].append(sc_copy)
            existing_scenes[sid] = sc_copy
        else:
            if scene.get('description'):
                existing_scenes[sid]['description'] = scene['description']
            if valid_cast:
                existing_scenes[sid]['cast'] = list(dict.fromkeys(existing_scenes[sid].get('cast', []) + valid_cast))

    for rid in touched_regions:
        if not rid:
            continue
        region_scene_ids = [s['id'] for s in story['scenes'] if s.get('region_id') == rid]
        for s in story['scenes']:
            if s.get('region_id') == rid:
                s['next'] = [oid for oid in region_scene_ids if oid != s['id']]
        if region_scene_ids:
            story['world'].setdefault('region_starts', {}).setdefault(rid, region_scene_ids[0])
    return story


def expansion_from_package(package):
    matches = [p for p in package.files if p == 'cloud/world-release.json' or p.endswith('/cloud/world-release.json')]
    if len(matches) == 1:
        return package.document('cloud/world-release.json')
    return None


def from_package(package, character_ids, required=True):
    matches = [p for p in package.files if p == 'release/content.json' or p.endswith('/release/content.json')]
    if not matches:
        exp = expansion_from_package(package)
        if exp and isinstance(exp.get('content'), dict):
            return validate(exp['content'], character_ids)
        if not required:
            return None
    if len(matches) != 1:
        raise engine.StoryError('請使用完整測試資料 ZIP，其中需要唯一的 release/content.json。')
    return validate(package.document('release/content.json'), character_ids)


def _apply_release_to_story(user_dir, story_id, content, expansion, expected_version):
    with engine._LOCK:
        story = engine.get_story(user_dir, story_id)
        if not story.get('world'):
            raise engine.StoryError('請先匯入魔法異世界。')
        ids = [c['id'] for c in story['characters'] if c['kind'] == 'important_character']
        content = validate(content, ids)
        current = story['world'].get('content_release', {})
        digest = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        has_new_expansion = bool(expansion and any(
            npc.get('id') not in {c['id'] for c in story['characters']}
            for npc in expansion.get('npcs', []) if isinstance(npc, dict)
        ))
        if digest(content) == digest(current) and not has_new_expansion:
            return {'story': story, 'already_installed': True}
        if expected_version is not None and expected_version != current.get('content_version', ''):
            raise engine.StoryError('設定已更新，請重新載入後再安裝；本次未覆蓋設定。')
        backup = engine._root(user_dir) / 'backups' / (engine._id(story_id) + '-content-' + digest(story)[:16] + '.json')
        backup.parent.mkdir(exist_ok=True)
        engine._write(backup, story)
        story['world']['content_release'] = content
        if expansion:
            apply_expansion(story, expansion)
        result = engine.validate_story(story, story_id)
        engine._write(engine._story_path(user_dir, story_id), result)
        return {'story': result, 'already_installed': False}


def install(user_dir, story_id, stream, expected_version):
    from world_import import Package
    pack = Package(stream)
    try:
        with engine._LOCK:
            story = engine.get_story(user_dir, story_id)
            if not story.get('world'):
                raise engine.StoryError('請先匯入魔法異世界。')
            ids = [c['id'] for c in story['characters'] if c['kind'] == 'important_character']
            content = from_package(pack, ids)
            expansion = expansion_from_package(pack)
        return _apply_release_to_story(user_dir, story_id, content, expansion, expected_version)
    finally:
        pack.close()


def install_bundled(user_dir, story_id, expected_version=None):
    if not BUNDLED_WORLD_RELEASE.is_file():
        raise engine.StoryError('找不到內建的 V1.5.0 發布設定檔。')
    raw = json.loads(BUNDLED_WORLD_RELEASE.read_text(encoding='utf-8'))
    content = raw.get('content') if isinstance(raw, dict) and 'content' in raw else raw
    expansion = raw if isinstance(raw, dict) and 'content' in raw else None
    return _apply_release_to_story(user_dir, story_id, content, expansion, expected_version)
